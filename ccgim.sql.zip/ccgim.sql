-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 30 jan. 2023 à 02:00
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ccgim`
--

-- --------------------------------------------------------

--
-- Structure de la table `galerie`
--

CREATE TABLE `galerie` (
  `id_galerie` int(111) NOT NULL,
  `date_galerie` datetime DEFAULT NULL,
  `logement_id` int(11) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `logement`
--

CREATE TABLE `logement` (
  `id_logement` int(111) NOT NULL,
  `date_lgt` datetime DEFAULT NULL,
  `udp_date` datetime DEFAULT NULL,
  `utilisateur_id` int(111) DEFAULT NULL,
  `nom_lgt` varchar(225) DEFAULT NULL,
  `slug_lgt` varchar(225) DEFAULT NULL,
  `categorie` int(11) DEFAULT NULL,
  `superficie` float DEFAULT NULL,
  `chambres` int(11) DEFAULT NULL,
  `bain` int(11) DEFAULT NULL,
  `lit` int(11) DEFAULT NULL,
  `description` varchar(225) DEFAULT NULL,
  `infos_sup` varchar(225) DEFAULT NULL,
  `ville_lgt` varchar(225) DEFAULT NULL,
  `quartier_lgt` varchar(225) DEFAULT NULL,
  `nom_agent` varchar(225) DEFAULT NULL,
  `iso_phone_lgt` varchar(225) DEFAULT NULL,
  `dial_phone_lgt` varchar(225) DEFAULT NULL,
  `phone_lgt` varchar(225) DEFAULT NULL,
  `tarif` float DEFAULT NULL,
  `remise` float DEFAULT NULL,
  `nb_upd` int(1) NOT NULL DEFAULT 0,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `logement`
--

INSERT INTO `logement` (`id_logement`, `date_lgt`, `udp_date`, `utilisateur_id`, `nom_lgt`, `slug_lgt`, `categorie`, `superficie`, `chambres`, `bain`, `lit`, `description`, `infos_sup`, `ville_lgt`, `quartier_lgt`, `nom_agent`, `iso_phone_lgt`, `dial_phone_lgt`, `phone_lgt`, `tarif`, `remise`, `nb_upd`, `statut`) VALUES
(1, '2023-01-29 23:38:00', '2023-01-29 23:42:00', 1, 'Saint Paul de Vences', 'saint-paul-de-vences', 5, 23, 50, 50, 25, 'propri&eacute;t&eacute; propri&eacute;t&eacute; propri&eacute;t&eacute;', 'propri&eacute;t&eacute;', 'Chamb&eacute;sy', 'BAE', 'Ouattara', 'ci', '225', '0759716483', 250000, 25, 7, 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id_utilisateur` int(111) NOT NULL,
  `date_utilisateur` datetime DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `email_valid` int(1) NOT NULL DEFAULT 0,
  `mot_de_passe` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `prenom` varchar(225) DEFAULT NULL,
  `adresse` varchar(225) DEFAULT NULL,
  `ville` varchar(225) DEFAULT NULL,
  `pays` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `phone_valid` int(1) DEFAULT NULL,
  `date_phone` datetime DEFAULT NULL,
  `postale` varchar(225) DEFAULT NULL,
  `banque` varchar(225) DEFAULT NULL,
  `contribuable` varchar(225) DEFAULT NULL,
  `mecano` varchar(225) DEFAULT NULL,
  `service` varchar(225) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `bloquer` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `date_utilisateur`, `email`, `email_valid`, `mot_de_passe`, `slug`, `nom`, `prenom`, `adresse`, `ville`, `pays`, `iso_phone`, `dial_phone`, `phone`, `phone_valid`, `date_phone`, `postale`, `banque`, `contribuable`, `mecano`, `service`, `photo`, `bloquer`) VALUES
(1, '2022-06-22 09:50:00', 'zie.nanien@gmail.com', 1, '$2y$12$JxArIFEd1Bnd3fRUqKUYu.B9Kx0lynTLdQ18/DbL9G2hfwxfuopte', 'ouattara', 'Ouattara', 'Gnelezie', 'Adjam&eacute; 220 logements', 'Kass&eacute;r&eacute;', 'LV', 'ci', '225', '0759716483', 1, '2022-06-22 10:18:00', '408327', NULL, NULL, NULL, NULL, '63d1ad0a94872.jpg', 0),
(2, '2022-07-01 17:38:00', 'gnelezie.ouattara@uvci.edu.ci', 1, '$2y$12$D.CotUKfShSbFPZuFNuUFuu4iVxdNLQmhTugwewh894tW2xZ44EQu', 'kone', 'Kone', 'Zana', 'Zoo II plateau', 'Abidjan', 'BF', 'ci', '225', '0303030303', 1, '2022-07-01 17:40:00', '442344', NULL, NULL, NULL, NULL, NULL, 0),
(3, '2022-07-02 13:02:00', 'zie.naniens@gmail.com', 0, '$2y$12$6zlTDJjW5Lwc61//c0ovBOFZiLWp9Nh/vu2YUIxcYTsw9AFpWIPcG', 'kosse', 'Kosse', 'Teo', 'azerty', 'Abidjan', 'CI', 'ci', '225', '010101010', NULL, NULL, '296710', NULL, NULL, NULL, NULL, NULL, 0),
(4, '2023-01-24 04:54:00', 'Prnom@kk.mm', 0, '$2y$12$t65Wbr5Km/bUXAak/lohZenXbMvIR2kD1AlYq/GpzxedDMPBchafG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `galerie`
--
ALTER TABLE `galerie`
  ADD PRIMARY KEY (`id_galerie`);

--
-- Index pour la table `logement`
--
ALTER TABLE `logement`
  ADD PRIMARY KEY (`id_logement`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id_utilisateur`),
  ADD KEY `email` (`email`),
  ADD KEY `slug` (`slug`),
  ADD KEY `phone` (`phone`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `galerie`
--
ALTER TABLE `galerie`
  MODIFY `id_galerie` int(111) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `logement`
--
ALTER TABLE `logement`
  MODIFY `id_logement` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id_utilisateur` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
