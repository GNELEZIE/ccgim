-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 16 fév. 2023 à 11:00
-- Version du serveur : 10.4.24-MariaDB
-- Version de PHP : 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ccgim`
--

-- --------------------------------------------------------

--
-- Structure de la table `galerie`
--

CREATE TABLE `galerie` (
  `id_galerie` int(111) NOT NULL,
  `date_galerie` datetime DEFAULT NULL,
  `logement_id` int(11) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `galerie`
--

INSERT INTO `galerie` (`id_galerie`, `date_galerie`, `logement_id`, `photo`) VALUES
(1, '2023-01-31 06:17:00', 1, '63d8b286d6b9a.png'),
(2, '2023-01-31 06:17:00', 1, '63d8b28b79658.png'),
(3, '2023-01-31 06:17:00', 1, '63d8b29062692.png'),
(4, '2023-01-31 06:21:00', 2, '63d8b3690c011.jpg'),
(5, '2023-01-31 06:21:00', 2, '63d8b36d78c31.jpg'),
(6, '2023-01-31 06:21:00', 2, '63d8b370dcde9.jpg'),
(7, '2023-01-31 06:23:00', 3, '63d8b3da2f9c2.png'),
(8, '2023-01-31 06:23:00', 3, '63d8b3de116a0.png'),
(9, '2023-01-31 09:40:00', 4, '63d8e1f1a3078.jpg'),
(10, '2023-01-31 09:40:00', 4, '63d8e1f9320fc.jpg'),
(11, '2023-01-31 09:40:00', 4, '63d8e20025be3.jpg'),
(12, '2023-01-31 09:40:00', 4, '63d8e2093dd84.jpg'),
(13, '2023-01-31 09:40:00', 4, '63d8e20e46dfc.jpg'),
(14, '2023-01-31 11:36:00', 5, '63d8fd20a5bd6.jpg'),
(15, '2023-01-31 11:36:00', 5, '63d8fd2600d30.jpg'),
(16, '2023-01-31 11:36:00', 5, '63d8fd2be78b9.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `locataire`
--

CREATE TABLE `locataire` (
  `id_locataire` int(111) NOT NULL,
  `date_locataire` datetime DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `prenom` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `bail` varchar(225) DEFAULT NULL,
  `ville` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `lgt_id` int(11) DEFAULT NULL,
  `ref` varchar(225) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `locataire`
--

INSERT INTO `locataire` (`id_locataire`, `date_locataire`, `nom`, `prenom`, `slug`, `bail`, `ville`, `iso_phone`, `dial_phone`, `phone`, `lgt_id`, `ref`, `statut`) VALUES
(1, '2023-02-01 01:29:00', 'Gnelezie Arouna', 'Ouattara', 'ouattara', 'Complement bail', NULL, 'ci', '225', '111111111111', 5, NULL, 0),
(2, '2023-02-01 01:34:00', 'yougone', 'Ouattara', 'ouattara-1', 'Bouake', NULL, 'ci', '225', '000000000', 4, NULL, 0),
(3, '2023-02-01 02:22:00', 'Kone', 'Moussa', 'moussa', 'Bouake', NULL, 'ci', '225', '000000000', 3, NULL, 0),
(4, '2023-02-02 21:54:49', 'CCGIM', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Structure de la table `logement`
--

CREATE TABLE `logement` (
  `id_logement` int(111) NOT NULL,
  `date_lgt` datetime DEFAULT NULL,
  `udp_date` datetime DEFAULT NULL,
  `utilisateur_id` int(111) DEFAULT NULL,
  `nom_lgt` varchar(225) DEFAULT NULL,
  `slug_lgt` varchar(225) DEFAULT NULL,
  `categorie` int(11) DEFAULT NULL,
  `superficie` float DEFAULT NULL,
  `chambres` int(11) DEFAULT NULL,
  `bain` int(11) DEFAULT NULL,
  `lit` int(11) DEFAULT NULL,
  `description` varchar(225) DEFAULT NULL,
  `infos_sup` varchar(225) DEFAULT NULL,
  `ville_lgt` varchar(225) DEFAULT NULL,
  `quartier_lgt` varchar(225) DEFAULT NULL,
  `nom_agent` varchar(225) DEFAULT NULL,
  `iso_phone_lgt` varchar(225) DEFAULT NULL,
  `dial_phone_lgt` varchar(225) DEFAULT NULL,
  `phone_lgt` varchar(225) DEFAULT NULL,
  `tarif` float DEFAULT NULL,
  `remise` float DEFAULT NULL,
  `nb_upd` int(1) NOT NULL DEFAULT 0,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `logement`
--

INSERT INTO `logement` (`id_logement`, `date_lgt`, `udp_date`, `utilisateur_id`, `nom_lgt`, `slug_lgt`, `categorie`, `superficie`, `chambres`, `bain`, `lit`, `description`, `infos_sup`, `ville_lgt`, `quartier_lgt`, `nom_agent`, `iso_phone_lgt`, `dial_phone_lgt`, `phone_lgt`, `tarif`, `remise`, `nb_upd`, `statut`) VALUES
(1, '2023-01-31 06:16:00', NULL, 1, 'Family Apartment', 'family-apartment', 2, 23, 33, 2, 7, 'Description de la propri&eacute;t&eacute;', 'Description de la propri&eacute;t&eacute;', 'Abidjan', 'Adjam&eacute; Saint Michel', 'Coulibaly', 'ci', '225', '0101010101', 150000, 15, 2, 0),
(2, '2023-01-31 06:20:00', NULL, 1, 'Family Apartment 2', 'family-apartment-2', 3, 10, 63, 50, 21, 'Large Bed Rooms with 3 Verandas, Spacious Drawing, Dining &amp; Family Living Room, Highly Decorated Kitchen with Store Room and Servant room with attached Large Bed Rooms with 3 Verandas, Spacious Drawing, Dining &amp; Famil', 'Large Bed Rooms with 3 Verandas, Spacious Drawing, Dining &amp; Family Living Room, Highly Decorated Kitchen with Store Room and Servant room with attached', 'Abidjan', 'Abobo Dokui', 'Coulibaly', 'ci', '225', '0111111111111', 250000, 0, 2, 1),
(3, '2023-01-31 06:22:00', NULL, 1, 'Family Apartment 3', 'family-apartment-3', 4, 33.5, 5, 3, 11, 'Electricity with full generator load, b. Central Gas Geyser, c. 2 Car Parking with 1 Driver&rsquo;s Accommodation, d. Community Conference Hall, e. Roof Top Beautified Garden and Grassy Ground, f. Cloth Hanging facility with ', 'Electricity with full generator load, b. Central Gas Geyser, c. 2 Car Parking with 1 Driver&rsquo;s Accommodation, d. Community Conference Hall, e. Roof Top Beautified Garden and Grassy Ground, f. Cloth Hanging facility with ', 'Abidjan', 'Yopougon BAE', 'Coulibaly', 'ci', '225', '001010001', 350000, 30, 2, 0),
(4, '2023-01-31 09:33:00', NULL, 1, 'Family Apartment 4', 'family-apartment-4', 2, 362, 5, 2, 5, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo cons', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam', 'Abidjan', 'Koumassi Remblais', 'Coulibaly', 'ci', '225', '000000000', 150000, 30, 5, 0),
(5, '2023-01-31 11:32:00', NULL, 5, 'Saint Paul de Vences', 'saint-paul-de-vences', 3, 23, 5, 3, 7, 'Description de la propri&eacute;t&eacute;', 'Informations suppl&eacute;mentaires', 'Abidjan', 'Adjam&eacute; Saint Michel', 'Coulibaly', 'ci', '225', '0707191186', 150000, 0, 2, 0);

-- --------------------------------------------------------

--
-- Structure de la table `tresorerie`
--

CREATE TABLE `tresorerie` (
  `id_tresorerie` int(111) NOT NULL,
  `date_tresorerie` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `type_transac` int(1) DEFAULT 0,
  `libelle_transac` varchar(225) DEFAULT NULL,
  `debit_transac` float DEFAULT 0,
  `credit_transac` float NOT NULL DEFAULT 0,
  `ref_paiement` varchar(225) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `tresorerie`
--

INSERT INTO `tresorerie` (`id_tresorerie`, `date_tresorerie`, `user_id`, `type_transac`, `libelle_transac`, `debit_transac`, `credit_transac`, `ref_paiement`, `statut`) VALUES
(1, '2023-03-17 00:00:00', 3, 1, 'Achat d\\&#039;appel Ghislain', 250000, 0, 'Ref0223000001', 0),
(2, '2023-03-05 00:00:00', 4, 2, 'Gain sur livraison', 0, 15000, 'Ref0223000002', 0),
(3, '2023-02-03 00:00:00', 1, 1, 'Achat d\\&#039;appel Ghislain', 60000, 0, 'Ref0223000003', 0),
(4, '2023-02-03 23:20:00', 2, 1, 'Entr&eacute;', 45000, 0, 'Ref0223000004', 0),
(5, '2023-02-03 00:00:00', 4, 2, 'Retrait', 0, 3000, 'Ref0223000005', 0);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id_utilisateur` int(111) NOT NULL,
  `date_utilisateur` datetime DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `email_valid` int(1) NOT NULL DEFAULT 0,
  `mot_de_passe` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `prenom` varchar(225) DEFAULT NULL,
  `adresse` varchar(225) DEFAULT NULL,
  `ville` varchar(225) DEFAULT NULL,
  `pays` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `phone_valid` int(1) DEFAULT NULL,
  `date_phone` datetime DEFAULT NULL,
  `postale` varchar(225) DEFAULT NULL,
  `banque` varchar(225) DEFAULT NULL,
  `contribuable` varchar(225) DEFAULT NULL,
  `mecano` varchar(225) DEFAULT NULL,
  `service` varchar(225) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `bloquer` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `date_utilisateur`, `email`, `email_valid`, `mot_de_passe`, `slug`, `nom`, `prenom`, `adresse`, `ville`, `pays`, `iso_phone`, `dial_phone`, `phone`, `phone_valid`, `date_phone`, `postale`, `banque`, `contribuable`, `mecano`, `service`, `photo`, `bloquer`) VALUES
(1, '2022-06-22 09:50:00', 'zie.nanien@gmail.com', 1, '$2y$12$JxArIFEd1Bnd3fRUqKUYu.B9Kx0lynTLdQ18/DbL9G2hfwxfuopte', 'gnelezie', 'Ouattara', 'Gnelezie', 'Adjam&eacute; 220 logements', 'Kass&eacute;r&eacute;', 'LV', 'ci', '225', '0759716483', 1, '2022-06-22 10:18:00', '408327', 'ffff02', 'ddd', '', '', '63d8573ef40ce.png', 0),
(2, '2022-07-01 17:38:00', 'gnelezie.ouattara@uvci.edu.ci', 1, '$2y$12$D.CotUKfShSbFPZuFNuUFuu4iVxdNLQmhTugwewh894tW2xZ44EQu', 'kone', 'Kone', 'Zana', 'Zoo II plateau', 'Abidjan', 'BF', 'ci', '225', '0303030303', 1, '2022-07-01 17:40:00', '442344', NULL, NULL, NULL, NULL, NULL, 0),
(3, '2022-07-02 13:02:00', 'zie.naniens@gmail.com', 0, '$2y$12$6zlTDJjW5Lwc61//c0ovBOFZiLWp9Nh/vu2YUIxcYTsw9AFpWIPcG', 'kosse', 'Kosse', 'Teo', 'azerty', 'Abidjan', 'CI', 'ci', '225', '010101010', NULL, NULL, '296710', NULL, NULL, NULL, NULL, NULL, 0),
(4, '2023-01-24 04:54:00', 'Prnom@kk.mm', 0, '$2y$12$t65Wbr5Km/bUXAak/lohZenXbMvIR2kD1AlYq/GpzxedDMPBchafG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(5, NULL, 'thierryadam.mcg@gmail.com', 0, '$2y$12$nbABJTowlh9Oi0oAmFXlp.LvgewdZNpjCo9Rh2pPRNoPk3UIsBqIC', 'thierry', 'Coulibaly', 'Thierry', NULL, 'Abidjan', NULL, 'ci', '225', '0707191186', NULL, NULL, '002525', '0000000', '0000', '0000', '0000', '63d8fbe0dfe60.jpg', 0),
(6, '2023-02-01 08:06:10', 'support@cabinet-ccgim.com', 0, '$2y$12$L.TPUPsNOYlbIqoqZrVa0u3AUei3QjEWov5VN12ovxMzv60lIcBh2', 'super', 'Admin', 'Super', NULL, 'Abidjan', NULL, 'ci', '225', '000000000', NULL, NULL, '225', '2555', '558', 'sdd', '0000', NULL, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `galerie`
--
ALTER TABLE `galerie`
  ADD PRIMARY KEY (`id_galerie`);

--
-- Index pour la table `locataire`
--
ALTER TABLE `locataire`
  ADD PRIMARY KEY (`id_locataire`);

--
-- Index pour la table `logement`
--
ALTER TABLE `logement`
  ADD PRIMARY KEY (`id_logement`);

--
-- Index pour la table `tresorerie`
--
ALTER TABLE `tresorerie`
  ADD PRIMARY KEY (`id_tresorerie`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id_utilisateur`),
  ADD KEY `email` (`email`),
  ADD KEY `slug` (`slug`),
  ADD KEY `phone` (`phone`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `galerie`
--
ALTER TABLE `galerie`
  MODIFY `id_galerie` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `locataire`
--
ALTER TABLE `locataire`
  MODIFY `id_locataire` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `logement`
--
ALTER TABLE `logement`
  MODIFY `id_logement` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `tresorerie`
--
ALTER TABLE `tresorerie`
  MODIFY `id_tresorerie` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id_utilisateur` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
