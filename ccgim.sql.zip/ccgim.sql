-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 04 fév. 2023 à 10:03
-- Version du serveur : 10.4.19-MariaDB
-- Version de PHP : 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ccgim`
--

-- --------------------------------------------------------

--
-- Structure de la table `galerie`
--

CREATE TABLE `galerie` (
  `id_galerie` int(111) NOT NULL,
  `date_galerie` datetime DEFAULT NULL,
  `logement_id` int(11) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `locataire`
--

CREATE TABLE `locataire` (
  `id_locataire` int(111) NOT NULL,
  `date_locataire` datetime DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `prenom` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `bail` varchar(225) DEFAULT NULL,
  `ville` varchar(50) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `lgt_id` int(11) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `locataire`
--

INSERT INTO `locataire` (`id_locataire`, `date_locataire`, `nom`, `prenom`, `slug`, `bail`, `ville`, `iso_phone`, `dial_phone`, `phone`, `lgt_id`, `statut`) VALUES
(1, '2023-02-04 08:56:00', 'CCGIM', 'APPP', 'appp', 'Complement bail', 'Abidjan', 'ci', '225', '00000000', 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `logement`
--

CREATE TABLE `logement` (
  `id_logement` int(111) NOT NULL,
  `date_lgt` datetime DEFAULT NULL,
  `udp_date` datetime DEFAULT NULL,
  `utilisateur_id` int(111) DEFAULT NULL,
  `nom_lgt` varchar(225) DEFAULT NULL,
  `slug_lgt` varchar(225) DEFAULT NULL,
  `categorie` int(11) DEFAULT NULL,
  `superficie` float DEFAULT NULL,
  `chambres` int(11) DEFAULT NULL,
  `bain` int(11) DEFAULT NULL,
  `lit` int(11) DEFAULT NULL,
  `description` varchar(225) DEFAULT NULL,
  `infos_sup` varchar(225) DEFAULT NULL,
  `ville_lgt` varchar(225) DEFAULT NULL,
  `quartier_lgt` varchar(225) DEFAULT NULL,
  `nom_agent` varchar(225) DEFAULT NULL,
  `iso_phone_lgt` varchar(225) DEFAULT NULL,
  `dial_phone_lgt` varchar(225) DEFAULT NULL,
  `phone_lgt` varchar(225) DEFAULT NULL,
  `tarif` float DEFAULT NULL,
  `remise` float DEFAULT NULL,
  `nb_upd` int(1) NOT NULL DEFAULT 0,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `tresorerie`
--

CREATE TABLE `tresorerie` (
  `id_tresorerie` int(111) NOT NULL,
  `date_tresorerie` datetime DEFAULT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `type_transac` int(1) DEFAULT 0,
  `libelle_transac` varchar(225) DEFAULT NULL,
  `debit_transac` float DEFAULT 0,
  `credit_transac` float NOT NULL DEFAULT 0,
  `ref_paiement` varchar(225) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id_utilisateur` int(111) NOT NULL,
  `date_utilisateur` datetime DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `email_valid` int(1) NOT NULL DEFAULT 0,
  `mot_de_passe` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `prenom` varchar(225) DEFAULT NULL,
  `adresse` varchar(225) DEFAULT NULL,
  `ville` varchar(225) DEFAULT NULL,
  `pays` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `phone_valid` int(1) DEFAULT NULL,
  `date_phone` datetime DEFAULT NULL,
  `postale` varchar(225) DEFAULT NULL,
  `banque` varchar(225) DEFAULT NULL,
  `contribuable` varchar(225) DEFAULT NULL,
  `mecano` varchar(225) DEFAULT NULL,
  `service` varchar(225) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL,
  `bloquer` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `date_utilisateur`, `email`, `email_valid`, `mot_de_passe`, `slug`, `nom`, `prenom`, `adresse`, `ville`, `pays`, `iso_phone`, `dial_phone`, `phone`, `phone_valid`, `date_phone`, `postale`, `banque`, `contribuable`, `mecano`, `service`, `photo`, `bloquer`) VALUES
(1, '2022-06-22 09:50:00', 'zie.nanien@gmail.com', 1, '$2y$12$JxArIFEd1Bnd3fRUqKUYu.B9Kx0lynTLdQ18/DbL9G2hfwxfuopte', 'gnelezie', 'Ouattara', 'Gnelezie', 'Adjam&eacute; 220 logements', 'Kass&eacute;r&eacute;', 'LV', 'ci', '225', '0759716483', 1, '2022-06-22 10:18:00', '408327', 'ffff02', 'ddd', '', '', '63d8573ef40ce.png', 0),
(2, '2022-07-01 17:38:00', 'gnelezie.ouattara@uvci.edu.ci', 1, '$2y$12$D.CotUKfShSbFPZuFNuUFuu4iVxdNLQmhTugwewh894tW2xZ44EQu', 'kone', 'Kone', 'Zana', 'Zoo II plateau', 'Abidjan', 'BF', 'ci', '225', '0303030303', 1, '2022-07-01 17:40:00', '442344', NULL, NULL, NULL, NULL, NULL, 0),
(3, '2022-07-02 13:02:00', 'zie.naniens@gmail.com', 0, '$2y$12$6zlTDJjW5Lwc61//c0ovBOFZiLWp9Nh/vu2YUIxcYTsw9AFpWIPcG', 'kosse', 'Kosse', 'Teo', 'azerty', 'Abidjan', 'CI', 'ci', '225', '010101010', NULL, NULL, '296710', NULL, NULL, NULL, NULL, NULL, 0),
(4, '2023-01-24 04:54:00', 'Prnom@kk.mm', 0, '$2y$12$t65Wbr5Km/bUXAak/lohZenXbMvIR2kD1AlYq/GpzxedDMPBchafG', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(5, NULL, 'thierryadam.mcg@gmail.com', 0, '$2y$12$nbABJTowlh9Oi0oAmFXlp.LvgewdZNpjCo9Rh2pPRNoPk3UIsBqIC', 'thierry', 'Coulibaly', 'Thierry', NULL, 'Abidjan', NULL, 'ci', '225', '0707191186', NULL, NULL, '002525', '0000000', '0000', '0000', '0000', '63d8fbe0dfe60.jpg', 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `locataire`
--
ALTER TABLE `locataire`
  ADD PRIMARY KEY (`id_locataire`);

--
-- Index pour la table `tresorerie`
--
ALTER TABLE `tresorerie`
  ADD PRIMARY KEY (`id_tresorerie`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `locataire`
--
ALTER TABLE `locataire`
  MODIFY `id_locataire` int(111) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `tresorerie`
--
ALTER TABLE `tresorerie`
  MODIFY `id_tresorerie` int(111) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
