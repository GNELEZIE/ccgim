
-- --------------------------------------------------------

--
-- Structure de la table `galerie`
--

CREATE TABLE `galerie` (
  `id_galerie` int(111) NOT NULL,
  `date_galerie` datetime DEFAULT NULL,
  `logement_id` int(11) DEFAULT NULL,
  `photo` varchar(225) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `galerie`
--

INSERT INTO `galerie` (`id_galerie`, `date_galerie`, `logement_id`, `photo`) VALUES
(1, '2023-01-31 06:17:00', 1, '63d8b286d6b9a.png'),
(2, '2023-01-31 06:17:00', 1, '63d8b28b79658.png'),
(3, '2023-01-31 06:17:00', 1, '63d8b29062692.png'),
(4, '2023-01-31 06:21:00', 2, '63d8b3690c011.jpg'),
(5, '2023-01-31 06:21:00', 2, '63d8b36d78c31.jpg'),
(6, '2023-01-31 06:21:00', 2, '63d8b370dcde9.jpg'),
(7, '2023-01-31 06:23:00', 3, '63d8b3da2f9c2.png'),
(8, '2023-01-31 06:23:00', 3, '63d8b3de116a0.png'),
(9, '2023-01-31 09:40:00', 4, '63d8e1f1a3078.jpg'),
(10, '2023-01-31 09:40:00', 4, '63d8e1f9320fc.jpg'),
(11, '2023-01-31 09:40:00', 4, '63d8e20025be3.jpg'),
(12, '2023-01-31 09:40:00', 4, '63d8e2093dd84.jpg'),
(13, '2023-01-31 09:40:00', 4, '63d8e20e46dfc.jpg'),
(14, '2023-01-31 11:36:00', 5, '63d8fd20a5bd6.jpg'),
(15, '2023-01-31 11:36:00', 5, '63d8fd2600d30.jpg'),
(16, '2023-01-31 11:36:00', 5, '63d8fd2be78b9.jpg');
