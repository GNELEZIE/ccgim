
-- --------------------------------------------------------

--
-- Structure de la table `locataire`
--

CREATE TABLE `locataire` (
  `id_locataire` int(111) NOT NULL,
  `date_locataire` datetime DEFAULT NULL,
  `nom` varchar(225) DEFAULT NULL,
  `prenom` varchar(225) DEFAULT NULL,
  `slug` varchar(225) DEFAULT NULL,
  `bail` varchar(225) DEFAULT NULL,
  `iso_phone` varchar(225) DEFAULT NULL,
  `dial_phone` varchar(225) DEFAULT NULL,
  `phone` varchar(225) DEFAULT NULL,
  `lgt_id` int(11) DEFAULT NULL,
  `statut` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `locataire`
--

INSERT INTO `locataire` (`id_locataire`, `date_locataire`, `nom`, `prenom`, `slug`, `bail`, `iso_phone`, `dial_phone`, `phone`, `lgt_id`, `statut`) VALUES
(1, '2023-02-01 01:29:00', 'Gnelezie Arouna', 'Ouattara', 'ouattara', 'Complement bail', 'ci', '225', '111111111111', 5, 0),
(2, '2023-02-01 01:34:00', 'yougone', 'Ouattara', 'ouattara-1', 'Bouake', 'ci', '225', '000000000', 4, 0),
(3, '2023-02-01 02:22:00', 'Kone', 'Moussa', 'moussa', 'Bouake', 'ci', '225', '000000000', 3, 0);
