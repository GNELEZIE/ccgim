
-- --------------------------------------------------------

--
-- Structure de la table `logement`
--

CREATE TABLE `logement` (
  `id_logement` int(111) NOT NULL,
  `date_lgt` datetime DEFAULT NULL,
  `udp_date` datetime DEFAULT NULL,
  `utilisateur_id` int(111) DEFAULT NULL,
  `nom_lgt` varchar(225) DEFAULT NULL,
  `slug_lgt` varchar(225) DEFAULT NULL,
  `categorie` int(11) DEFAULT NULL,
  `superficie` float DEFAULT NULL,
  `chambres` int(11) DEFAULT NULL,
  `bain` int(11) DEFAULT NULL,
  `lit` int(11) DEFAULT NULL,
  `description` varchar(225) DEFAULT NULL,
  `infos_sup` varchar(225) DEFAULT NULL,
  `ville_lgt` varchar(225) DEFAULT NULL,
  `quartier_lgt` varchar(225) DEFAULT NULL,
  `nom_agent` varchar(225) DEFAULT NULL,
  `iso_phone_lgt` varchar(225) DEFAULT NULL,
  `dial_phone_lgt` varchar(225) DEFAULT NULL,
  `phone_lgt` varchar(225) DEFAULT NULL,
  `tarif` float DEFAULT NULL,
  `remise` float DEFAULT NULL,
  `nb_upd` int(1) NOT NULL DEFAULT 0,
  `statut` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `logement`
--

INSERT INTO `logement` (`id_logement`, `date_lgt`, `udp_date`, `utilisateur_id`, `nom_lgt`, `slug_lgt`, `categorie`, `superficie`, `chambres`, `bain`, `lit`, `description`, `infos_sup`, `ville_lgt`, `quartier_lgt`, `nom_agent`, `iso_phone_lgt`, `dial_phone_lgt`, `phone_lgt`, `tarif`, `remise`, `nb_upd`, `statut`) VALUES
(1, '2023-01-31 06:16:00', NULL, 1, 'Family Apartment', 'family-apartment', 2, 23, 33, 2, 7, 'Description de la propri&eacute;t&eacute;', 'Description de la propri&eacute;t&eacute;', 'Abidjan', 'Adjam&eacute; Saint Michel', 'Coulibaly', 'ci', '225', '0101010101', 150000, 15, 2, 0),
(2, '2023-01-31 06:20:00', NULL, 1, 'Family Apartment 2', 'family-apartment-2', 3, 10, 63, 50, 21, 'Large Bed Rooms with 3 Verandas, Spacious Drawing, Dining &amp; Family Living Room, Highly Decorated Kitchen with Store Room and Servant room with attached Large Bed Rooms with 3 Verandas, Spacious Drawing, Dining &amp; Famil', 'Large Bed Rooms with 3 Verandas, Spacious Drawing, Dining &amp; Family Living Room, Highly Decorated Kitchen with Store Room and Servant room with attached', 'Abidjan', 'Abobo Dokui', 'Coulibaly', 'ci', '225', '0111111111111', 250000, 0, 2, 1),
(3, '2023-01-31 06:22:00', NULL, 1, 'Family Apartment 3', 'family-apartment-3', 4, 33.5, 5, 3, 11, 'Electricity with full generator load, b. Central Gas Geyser, c. 2 Car Parking with 1 Driver&rsquo;s Accommodation, d. Community Conference Hall, e. Roof Top Beautified Garden and Grassy Ground, f. Cloth Hanging facility with ', 'Electricity with full generator load, b. Central Gas Geyser, c. 2 Car Parking with 1 Driver&rsquo;s Accommodation, d. Community Conference Hall, e. Roof Top Beautified Garden and Grassy Ground, f. Cloth Hanging facility with ', 'Abidjan', 'Yopougon BAE', 'Coulibaly', 'ci', '225', '001010001', 350000, 30, 2, 0),
(4, '2023-01-31 09:33:00', NULL, 1, 'Family Apartment 4', 'family-apartment-4', 2, 362, 5, 2, 5, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo cons', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam', 'Abidjan', 'Koumassi Remblais', 'Coulibaly', 'ci', '225', '000000000', 150000, 30, 5, 0),
(5, '2023-01-31 11:32:00', NULL, 5, 'Saint Paul de Vences', 'saint-paul-de-vences', 3, 23, 5, 3, 7, 'Description de la propri&eacute;t&eacute;', 'Informations suppl&eacute;mentaires', 'Abidjan', 'Adjam&eacute; Saint Michel', 'Coulibaly', 'ci', '225', '0707191186', 150000, 0, 2, 0);
